package com.example.shoppinglist

import android.app.Application
import com.example.shoppinglist.data.db.ShoppingDatabase
import com.example.shoppinglist.data.repositories.ShoppingRepository
import com.example.shoppinglist.ui.shoppinglist.ShoppingViewModelFactory
import org.kodein.di.Kodein
import org.kodein.di.KodeinAware
import org.kodein.di.android.x.androidXModule
import org.kodein.di.generic.bind
import org.kodein.di.generic.instance
import org.kodein.di.generic.provider
import org.kodein.di.generic.singleton

//bunu manifeste eklemek gerekiyor
//implemented from Application(),  Implement KodeinAware interface
//bu class DI için, activity classta tek tek çağırmak düzensiz oluyor o yüzden düzen için gerekli
class ShoppingApplication: Application(), KodeinAware {

    //instance management için Application Scope lazım bu yüzden ayrı class
    //lazy means inside that block we can use application context during Binding(?) time
    //bc we need that for our ShoppingDB for which takes context as a param
    override val kodein: Kodein = Kodein.lazy{
        import(androidXModule(this@ShoppingApplication))
        bind() from singleton { //database'i aldık Activityde gerek yok artık
            ShoppingDatabase(instance())    //lazy kullandığımızdan instancede Application context gidiyor
        }
        bind() from singleton {
            ShoppingRepository(instance())  // en son database'i instanceladık singleton olduğundan da tek error verdirmez onu çeker
        }
        bind() from provider { //bu instance'ı ShoppingActivityde kullancaz burda çekmicez o yüzden sağlayıcı olmalı tek olması önemli değil
            ShoppingViewModelFactory(instance())    //instance, instancelar arasından kalıba uyan lazım olanı seçip alıyor sanırım
            //Shopping Repository'i bir variable'a eşitleyip onu atasak da olurdu sanırım
        }
    }
}