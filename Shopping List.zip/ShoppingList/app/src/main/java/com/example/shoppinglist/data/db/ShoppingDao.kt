package com.example.shoppinglist.data.db

import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.shoppinglist.data.db.entities.ShoppingItem

//tell room that this is Dao interface
@Dao
interface ShoppingDao {

    //eğer operation read dışında işlem içeriyorsa fonksiyon suspendle yazılır çünkü
    // bu fonksiyonlar viewModelda coroutine ile çağrılır
    //mix of update and insert is upsert
    @Insert(onConflict = OnConflictStrategy.REPLACE)    //if is available in db update it else insert it
    suspend fun upsert(item: ShoppingItem)
    //throw ya da coroutine gerekiyormuş o yüzden? call funcs asynchronously (eş zamanlı olmadan) suspendle çağır

    @Delete
    suspend fun delete(item: ShoppingItem)

    @Query("SELECT * FROM shopping_items")  //databaseteki gibi hepsini seçiyor <Table Nameden>
    fun getAllShoppingItems(): LiveData<List<ShoppingItem>>
}