package com.example.shoppinglist.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.shoppinglist.data.db.entities.ShoppingItem

@Database(
    entities = [ShoppingItem::class],       //array çünkü birden çok entity olabilir
    version = 1
)
abstract class ShoppingDatabase: RoomDatabase() {   //Inherited from room database

    abstract fun getShoppingDao() : ShoppingDao     //return ShoppingDao  so we access database operations inside db class
    //çağrıldığında bu interface de geliyor bu durumda

    companion object{   //static gibi her biri için ayrı olmayan tek olan
        //create instance of db inside the class called singleton, 1 tane olması için??
        @Volatile       //do that for only 1 thread at a time is writing to that instance yoksa aynı anda aynı 2 instance olabilir
        private var instance: ShoppingDatabase? = null //en başta null olduğundan böyle sanırım. Nullable

        private val LOCK = Any()

        //operator means this function executed whenever we create an instance of ShoppingDatabase class
        // X?: means that if (X.is_null())
        //return if instance is null return synchronized (make sure that no other threads will access that instance at the same time
        operator fun invoke(context: Context) = instance ?: synchronized(LOCK){
            instance ?: createDatabase(context).also { instance = it }  //it elementin adıydı lambda funclarda
        }
        //it is called everytime we create an instance of ShoppingDatabase and it will return our instance
        //but if our instance is null it will call synchronized blocks so no other threads can set the instance
        //at the time we execute code inside of that block in that block if it is still null we create it
        //also means we set our instance after calling method whatever the result of that method is

        private fun createDatabase(context: Context) =
            Room.databaseBuilder(
                context.applicationContext,
                ShoppingDatabase::class.java,
            "ShoppingDB.db"     //dbnin adı sanırım ama kullanılmıyor bir yerde aktif
            ).build()

    }
}