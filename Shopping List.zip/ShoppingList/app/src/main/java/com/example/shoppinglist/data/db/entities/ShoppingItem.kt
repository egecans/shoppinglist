package com.example.shoppinglist.data.db.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
//in order to make some operations CRUD + get with room we need to an interface Dao data access object

//entity in sql is just a table or database inside them we declare what shopping items look like
@Entity(tableName = "shopping_items")
data class ShoppingItem(
    @ColumnInfo(name = "item_name")
    var name: String,   //they (parameters) represent a column in database or table
    @ColumnInfo(name = "item_amount")
    var amount: Int
) {    //data class basically tells kotlin compiler that main purpose of that class is to hold data
    //table must have Primary Key because they recognize objects from there so you need to add it
    @PrimaryKey(autoGenerate = true)
    public var id: Int? = null  //room version güncel olmayınca sorun yarattı güncelleyince çözüldü
}