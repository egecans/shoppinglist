package com.example.shoppinglist.data.repositories

import com.example.shoppinglist.data.db.ShoppingDatabase
import com.example.shoppinglist.data.db.entities.ShoppingItem

//inside repo we implement db methods in dao  provides these methods for viewModel
//viewModel can call the methods from repository
//olayı daha önce tanımladığın abstractı çağırmak o anki database ile
class ShoppingRepository (
    private val db: ShoppingDatabase
        ){
    //dbmizi çağırdık parametrede dao interface de geldi o zaman burada fonksiyonları return edebiliriz
    suspend fun upsert(item: ShoppingItem) {
        return db.getShoppingDao().upsert(item)
    }
    suspend fun delete(item:ShoppingItem) = db.getShoppingDao().delete(item)
    fun getAllShoppingItems() = db.getShoppingDao().getAllShoppingItems()
}