package com.example.shoppinglist.other

import com.example.shoppinglist.data.db.entities.ShoppingItem

//inside the AddShoppingItemDialog class we need to tell ShoppingActivity class the result of the dialog
//so when we create a new item here we need to send that item to shopping activity
//because AddShoppingItemDialog is not an activity class we cannot call the setresult method
//we can do that for this interface
interface AddDialogListener {
    fun onAddButtonClicked(item: ShoppingItem)  //whenever we call this fun in class
    //we passed the item we created in dialog class, then we can get that item in shopping activity class
}