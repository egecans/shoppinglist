package com.example.shoppinglist.other

import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatDialog
import com.example.shoppinglist.R
import com.example.shoppinglist.data.db.entities.ShoppingItem
import kotlinx.android.synthetic.main.dialog_add_shopping_item.*

class AddShoppingItemDialog(
    context: Context,
    var addDialogListener: AddDialogListener): AppCompatDialog(context) {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.dialog_add_shopping_item)


        tvAdd.setOnClickListener{
            val name = etName.text.toString()
            val amount = etAmount.text.toString()

            if(name.isEmpty() || amount.isEmpty()){ //boş bırakırsa geri dönsün diye
                Toast.makeText(context,"Please enter all the boxes", Toast.LENGTH_SHORT).show()
                return@setOnClickListener   //bir daha başa git doldur demek
            }
            val item = ShoppingItem(name,amount.toInt())
            addDialogListener.onAddButtonClicked(item)  //notify the shopping activity and give it the item we created here
            dismiss()
        }
        tvCancel.setOnClickListener{
            cancel()
        }

    }
}