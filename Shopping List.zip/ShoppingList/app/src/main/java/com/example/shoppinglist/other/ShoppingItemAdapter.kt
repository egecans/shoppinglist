package com.example.shoppinglist.other

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.shoppinglist.R
import com.example.shoppinglist.data.db.entities.ShoppingItem
import com.example.shoppinglist.ui.shoppinglist.ShoppingViewModel
import kotlinx.android.synthetic.main.shopping_item.view.*

//recycler view class
//xmldeki işlemler burada yapılıyor, shopping_itemdekiler yani
class ShoppingItemAdapter (
    var items: List<ShoppingItem>,  //shopping itemler gelmeli
    private val viewModel: ShoppingViewModel    //dataları silip artırmamız gerek bunu da viewModelde yapıyorduk
): RecyclerView.Adapter<ShoppingItemAdapter.ShoppingViewHolder>(){

    //class içinde class açtı recyclerViewdan inherited bir şey ama bir şeye dönmedi anlamadım?
    //tutuyor sadece o anki viewu, recycleda döngü var çünkü anlığı alıyor hepsini ram'e yüklemiyor
    inner class ShoppingViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)

    //error vardı hala ctrl + o değil ctrl + i ile seçtik bu sefer ctrl + i error verdirtenler +o ise tüm mirasları veriyor ??
    //bişi anlamadım bu fonksiyondan ama lazım sanırım
    //bir de shopping_item'ın olduğunu belli ediyor setContentView gibi
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ShoppingViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.shopping_item, parent,false)
        return ShoppingViewHolder(view)
    }

    //her şeyi burada yapıp matchliyorsun sanırım
    override fun onBindViewHolder(holder: ShoppingViewHolder, position: Int) {
        val currShoppingItem = items[position]  //parametrelerden biri index gibi bir şey sanırım doğru şeyle işlem yapmak için

        holder.itemView.tvName.text = currShoppingItem.name
        holder.itemView.tvAmount.text = "${currShoppingItem.amount}"    //text string olduğundan böyle atanabiliyor

        holder.itemView.ivDelete.setOnClickListener {
            viewModel.delete(currShoppingItem) }    //delete imgsine operation atadık

        holder.itemView.ivMinus.setOnClickListener {
            if (currShoppingItem.amount > 0){   //negatif olmasın
                currShoppingItem.amount--
                viewModel.upsert(currShoppingItem)  //güncellemen lazım
            }
        }

        holder.itemView.ivPlus.setOnClickListener {
            currShoppingItem.amount++
            viewModel.upsert(currShoppingItem)
        }

    }

    //item counta dönmesi lazım
    override fun getItemCount(): Int {
        return items.size
    }



}