package com.example.shoppinglist.ui.shoppinglist

import androidx.lifecycle.ViewModel
import com.example.shoppinglist.data.db.entities.ShoppingItem
import com.example.shoppinglist.data.repositories.ShoppingRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ShoppingViewModel (
    private val repository: ShoppingRepository
    ) :ViewModel() {


        //dispatcher.main means: if you create a new coroutine we have to tell kotlin to which context we want to start with
        //in this case we want to start with main thread room provides Main safety but normally start with IO
        fun upsert(item: ShoppingItem) = CoroutineScope(Dispatchers.Main).launch {
            repository.upsert(item)
        }
    //bunlar writing operation olduğu için coroutinele olur
        fun delete(item: ShoppingItem) = CoroutineScope(Dispatchers.Main).launch {
        repository.delete(item)
    }
        //ama bu only read içerdiği için coroutine e gerek yok bu yüzden suspendsiz
        fun getAllShoppingItems() = repository.getAllShoppingItems()
}